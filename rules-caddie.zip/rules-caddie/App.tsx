import React, { useEffect, useState } from "react";
import { ActivityIndicator, View } from "react-native";
import { NavigationContainer, DefaultTheme } from "@react-navigation/native";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import { SafeAreaProvider } from "react-native-safe-area-context";
import type { Session } from "@supabase/supabase-js";
import { supabase } from "./src/lib/supabase";
import { c } from "./src/theme";
import AuthScreen from "./src/screens/AuthScreen";
import AskScreen from "./src/screens/AskScreen";
import RoundsScreen from "./src/screens/RoundsScreen";
import RoundScreen from "./src/screens/RoundScreen";

const Tabs = createBottomTabNavigator();
const Stack = createNativeStackNavigator();
const theme = { ...DefaultTheme, colors: { ...DefaultTheme.colors, background: c.paper, primary: c.fairway, card: c.paper, text: c.ink } };

function Main() {
  return (
    <Tabs.Navigator screenOptions={{ tabBarActiveTintColor: c.fairway, headerTitleStyle: { color: c.fairway } }}>
      <Tabs.Screen name="Ask" component={AskScreen} options={{ title: "Ask a rule" }} />
      <Tabs.Screen name="Rounds" component={RoundsScreen} options={{ title: "My rounds" }} />
    </Tabs.Navigator>
  );
}

export default function App() {
  const [session, setSession] = useState<Session | null>(null);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => { setSession(data.session); setReady(true); });
    const { data: sub } = supabase.auth.onAuthStateChange((_e, s) => setSession(s));
    return () => sub.subscription.unsubscribe();
  }, []);

  if (!ready) return <View style={{ flex: 1, justifyContent: "center" }}><ActivityIndicator color={c.fairway} /></View>;

  return (
    <SafeAreaProvider>
      <NavigationContainer theme={theme}>
        {session ? (
          <Stack.Navigator>
            <Stack.Screen name="Main" component={Main} options={{ headerShown: false }} />
            <Stack.Screen name="Round" component={RoundScreen} options={({ route }: any) => ({ title: route.params?.name ?? "Round" })} />
          </Stack.Navigator>
        ) : (
          <Stack.Navigator screenOptions={{ headerShown: false }}>
            <Stack.Screen name="Auth" component={AuthScreen} />
          </Stack.Navigator>
        )}
      </NavigationContainer>
    </SafeAreaProvider>
  );
}
