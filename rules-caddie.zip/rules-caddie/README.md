# Rules Caddie (starter)

Golf rules assistant: ask questions, photograph your lie, share situations with your group and vote.
Expo (React Native) app for iOS + Android, Supabase backend, Claude API for answers.

## 1. Create the app shell
```bash
npx create-expo-app@latest rules-caddie --template blank-typescript
cd rules-caddie
# copy this project's files over the new ones: App.tsx, app.json, src/, supabase/, .env.example
npx expo install expo-camera expo-image-manipulator @react-native-async-storage/async-storage \
  react-native-url-polyfill react-native-screens react-native-safe-area-context
npm install @supabase/supabase-js @react-navigation/native @react-navigation/bottom-tabs @react-navigation/native-stack
```

## 2. Supabase (supabase.com, free tier is fine)
1. Create a project. Copy the URL and anon key into `.env` (see `.env.example`).
2. SQL Editor: run `supabase/migrations/001_init.sql`, then `002_seed_sample_rules.sql`.
3. Install the Supabase CLI, then:
```bash
supabase login && supabase link --project-ref YOUR-REF
supabase secrets set ANTHROPIC_API_KEY=sk-ant-...      # key from console.anthropic.com
supabase functions deploy rules-assistant
```
(Optional: `supabase secrets set ANTHROPIC_MODEL=<model id>` to change the model.)

## 3. Run
```bash
npx expo start      # scan the QR code with Expo Go on your phone
```
Camera works on a real phone, not most simulators.

## 4. Before you publish
- **Rules text:** the 10 sample rules are short paraphrases for prototyping. Get a license from the USGA/R&A for the full text, and do not use "USGA" or "Official" in the name until permitted.
- **Store builds:** `npm i -g eas-cli && eas build` for iOS and Android. Needs Apple Developer ($99/yr) and Google Play ($25 once).
- **Required for review:** privacy policy URL, account deletion option (Apple requires it), camera usage text (already in app.json), AI-output disclaimer (already in Ask screen).
- **Testing:** have real players and a rules official check answers across many scenarios before launch.

## What's built / what's next
Built: sign-in, rules Q&A with citations and confidence, photo-assisted questions, rounds with join codes, shared situations, realtime agree/disagree votes.
Next: full rules content, comments on votes, GPS + course data, live video (LiveKit), rate limiting on the edge function, push notifications.
