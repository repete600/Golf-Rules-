// Supabase Edge Function (Deno). Deploy: supabase functions deploy rules-assistant
// Secrets: supabase secrets set ANTHROPIC_API_KEY=sk-ant-...
import { createClient } from "npm:@supabase/supabase-js@2";

const MODEL = Deno.env.get("ANTHROPIC_MODEL") ?? "claude-sonnet-5-5";
const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};
const json = (b: unknown, status = 200) =>
  new Response(JSON.stringify(b), { status, headers: { ...cors, "Content-Type": "application/json" } });

async function claude(system: string, content: unknown[], maxTokens = 1200): Promise<string> {
  const res = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "x-api-key": Deno.env.get("ANTHROPIC_API_KEY")!,
      "anthropic-version": "2023-06-01",
      "content-type": "application/json",
    },
    body: JSON.stringify({ model: MODEL, max_tokens: maxTokens, system, messages: [{ role: "user", content }] }),
  });
  if (!res.ok) throw new Error(`Claude API ${res.status}: ${await res.text()}`);
  const data = await res.json();
  return data.content.filter((b: any) => b.type === "text").map((b: any) => b.text).join("");
}

const parseJson = (t: string) => JSON.parse(t.replace(/```json|```/g, "").trim());

const EXTRACT_SYSTEM = `You help a golf rules assistant. From the player's question (and photo if given), return ONLY JSON:
{"situation_summary": "1-2 sentences of what is visible or described, no guessing",
 "search_keywords": ["6-10 rules-related keywords, e.g. bunker, penalty area, cart path, drop, relief, lost ball"]}
Only describe what you can actually see. Never invent details such as ball position, distances or marker colors you cannot confirm.`;

const ANSWER_SYSTEM = `You are Rules Caddie, a golf rules assistant for recreational and competitive players.
Answer ONLY using the RULES provided below. If the provided rules do not clearly cover the situation, say so, set confidence to "low" and needs_official to true.
Never state a rule number that is not in the provided RULES. Do not invent distances, penalties or procedures.
If key facts are missing (for example: which color penalty area, is it a bunker or general area, stroke play or match play), ask ONE short follow_up_question and give a conditional answer.
You give guidance, not binding rulings. Be concise and practical.
Return ONLY JSON with this exact shape:
{"situation_summary": string,
 "answer": string (2-4 sentences, plain language),
 "steps": string[] (ordered actions the player takes, may be empty),
 "rules_cited": [{"rule_number": string, "title": string}],
 "confidence": "high" | "medium" | "low",
 "needs_official": boolean,
 "follow_up_question": string | null}`;

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  try {
    const authHeader = req.headers.get("Authorization") ?? "";
    const supabase = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_ANON_KEY")!, {
      global: { headers: { Authorization: authHeader } },
    });
    const { data: u } = await supabase.auth.getUser();
    if (!u?.user) return json({ error: "Please sign in." }, 401);

    const { question, imageBase64 } = await req.json();
    if (!question || typeof question !== "string" || question.length > 1500) {
      return json({ error: "Please enter a question under 1500 characters." }, 400);
    }
    if (imageBase64 && imageBase64.length > 6_000_000) return json({ error: "Photo is too large." }, 400);

    // Step 1: understand the situation + build search keywords
    const userContent: unknown[] = [];
    if (imageBase64) {
      userContent.push({ type: "image", source: { type: "base64", media_type: "image/jpeg", data: imageBase64 } });
    }
    userContent.push({ type: "text", text: `Player question: ${question}` });
    const extracted = parseJson(await claude(EXTRACT_SYSTEM, userContent, 400));

    // Step 2: retrieve matching rules (full-text search)
    const q = [...(extracted.search_keywords ?? []), ...question.split(/\s+/).slice(0, 8)].join(" or ");
    const { data: rules, error } = await supabase.rpc("search_rules", { q, n: 6 });
    if (error) throw error;

    const rulesText = (rules ?? []).map((r: any) => `Rule ${r.rule_number} — ${r.title}\n${r.body}`).join("\n\n");
    if (!rulesText) {
      return json({
        situation_summary: extracted.situation_summary,
        answer: "I couldn't find a matching rule in my library for this situation.",
        steps: [], rules_cited: [], confidence: "low", needs_official: true,
        follow_up_question: "Can you describe where your ball is (bunker, penalty area, green, rough)?",
      });
    }

    // Step 3: answer grounded in retrieved rules
    const answerContent: unknown[] = [];
    if (imageBase64) {
      answerContent.push({ type: "image", source: { type: "base64", media_type: "image/jpeg", data: imageBase64 } });
    }
    answerContent.push({
      type: "text",
      text: `RULES:\n${rulesText}\n\nSITUATION SEEN: ${extracted.situation_summary}\n\nPLAYER QUESTION: ${question}`,
    });
    const result = parseJson(await claude(ANSWER_SYSTEM, answerContent, 1200));

    // Safety: drop any citation that wasn't actually retrieved
    const allowed = new Set((rules ?? []).map((r: any) => r.rule_number));
    result.rules_cited = (result.rules_cited ?? []).filter((c: any) => allowed.has(c.rule_number));
    if (result.rules_cited.length === 0) { result.confidence = "low"; result.needs_official = true; }

    return json(result);
  } catch (e) {
    console.error(e);
    return json({ error: "The rules assistant had a problem. Please try again." }, 500);
  }
});
