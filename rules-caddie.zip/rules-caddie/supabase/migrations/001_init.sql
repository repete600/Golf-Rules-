-- ===== Rules (searchable text) =====
create table public.rules (
  id serial primary key,
  rule_number text not null unique,
  title text not null,
  body text not null,
  tsv tsvector generated always as (
    setweight(to_tsvector('english', title), 'A') || setweight(to_tsvector('english', body), 'B')
  ) stored
);
create index rules_tsv_idx on public.rules using gin (tsv);
alter table public.rules enable row level security;
create policy "rules readable" on public.rules for select to authenticated using (true);

create function public.search_rules(q text, n int default 6)
returns table (rule_number text, title text, body text, rank real)
language sql stable as $$
  select r.rule_number, r.title, r.body, ts_rank(r.tsv, websearch_to_tsquery('english', q))
  from public.rules r
  where r.tsv @@ websearch_to_tsquery('english', q)
  order by 4 desc limit n
$$;

-- ===== Rounds =====
create table public.rounds (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  join_code text not null unique default upper(substr(md5(random()::text), 1, 6)),
  created_by uuid not null default auth.uid() references auth.users,
  created_at timestamptz not null default now()
);
create table public.round_members (
  round_id uuid references public.rounds on delete cascade,
  user_id uuid references auth.users on delete cascade default auth.uid(),
  display_name text not null,
  joined_at timestamptz not null default now(),
  primary key (round_id, user_id)
);

create function public.is_round_member(rid uuid) returns boolean
language sql security definer stable set search_path = public as $$
  select exists (select 1 from public.round_members where round_id = rid and user_id = auth.uid())
$$;

alter table public.rounds enable row level security;
alter table public.round_members enable row level security;
create policy "members see rounds" on public.rounds for select to authenticated using (public.is_round_member(id));
create policy "members see members" on public.round_members for select to authenticated using (public.is_round_member(round_id));

create function public.create_round(round_name text, my_name text) returns public.rounds
language plpgsql security definer set search_path = public as $$
declare r public.rounds;
begin
  insert into public.rounds (name, created_by) values (round_name, auth.uid()) returning * into r;
  insert into public.round_members (round_id, user_id, display_name) values (r.id, auth.uid(), my_name);
  return r;
end $$;

create function public.join_round(code text, my_name text) returns public.rounds
language plpgsql security definer set search_path = public as $$
declare r public.rounds;
begin
  select * into r from public.rounds where join_code = upper(trim(code));
  if not found then raise exception 'No round with that code'; end if;
  insert into public.round_members (round_id, user_id, display_name) values (r.id, auth.uid(), my_name)
    on conflict do nothing;
  return r;
end $$;

-- ===== Situations and votes =====
create table public.situations (
  id uuid primary key default gen_random_uuid(),
  round_id uuid not null references public.rounds on delete cascade,
  author_id uuid not null default auth.uid() references auth.users,
  author_name text not null,
  question text not null,
  image_path text,
  ai_result jsonb,
  created_at timestamptz not null default now()
);
create table public.votes (
  situation_id uuid references public.situations on delete cascade,
  user_id uuid references auth.users default auth.uid(),
  vote text not null check (vote in ('agree', 'disagree')),
  comment text,
  primary key (situation_id, user_id)
);

create function public.is_situation_member(sid uuid) returns boolean
language sql security definer stable set search_path = public as $$
  select exists (select 1 from public.situations s join public.round_members m on m.round_id = s.round_id
                 where s.id = sid and m.user_id = auth.uid())
$$;

alter table public.situations enable row level security;
alter table public.votes enable row level security;
create policy "members read situations" on public.situations for select to authenticated using (public.is_round_member(round_id));
create policy "members post situations" on public.situations for insert to authenticated
  with check (public.is_round_member(round_id) and author_id = auth.uid());
create policy "members read votes" on public.votes for select to authenticated using (public.is_situation_member(situation_id));
create policy "members vote" on public.votes for insert to authenticated
  with check (public.is_situation_member(situation_id) and user_id = auth.uid());
create policy "members change vote" on public.votes for update to authenticated
  using (user_id = auth.uid()) with check (user_id = auth.uid());

-- ===== Photo storage (private; folder name = round id) =====
insert into storage.buckets (id, name, public) values ('situation-photos', 'situation-photos', false)
  on conflict do nothing;
create policy "members upload photos" on storage.objects for insert to authenticated
  with check (bucket_id = 'situation-photos' and public.is_round_member(((storage.foldername(name))[1])::uuid));
create policy "members view photos" on storage.objects for select to authenticated
  using (bucket_id = 'situation-photos' and public.is_round_member(((storage.foldername(name))[1])::uuid));

-- ===== Realtime =====
alter publication supabase_realtime add table public.situations, public.votes;
