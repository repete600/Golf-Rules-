import React, { useState } from "react";
import { Alert, KeyboardAvoidingView, Platform, Text, TextInput, View } from "react-native";
import { supabase } from "../lib/supabase";
import { Button } from "../components";
import { c, serif } from "../theme";

export default function AuthScreen() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [mode, setMode] = useState<"in" | "up">("in");
  const [busy, setBusy] = useState(false);

  async function submit() {
    setBusy(true);
    const { error, data } = mode === "in"
      ? await supabase.auth.signInWithPassword({ email, password })
      : await supabase.auth.signUp({ email, password });
    setBusy(false);
    if (error) return Alert.alert("Couldn't sign in", error.message);
    if (mode === "up" && !data.session) Alert.alert("Check your email", "Confirm your address, then sign in.");
  }

  const input = { borderWidth: 1, borderColor: c.line, backgroundColor: c.white, borderRadius: 10, padding: 14, fontSize: 16, color: c.ink } as const;
  return (
    <KeyboardAvoidingView behavior={Platform.OS === "ios" ? "padding" : undefined} style={{ flex: 1, justifyContent: "center", padding: 24, gap: 14, backgroundColor: c.paper }}>
      <Text style={{ fontFamily: serif, fontSize: 38, color: c.fairway, fontWeight: "700" }}>Rules Caddie</Text>
      <Text style={{ color: c.rough, fontSize: 16, marginBottom: 12 }}>Ask the rulebook. Show your lie. Settle it with your group.</Text>
      <TextInput style={input} placeholder="Email" autoCapitalize="none" keyboardType="email-address" value={email} onChangeText={setEmail} />
      <TextInput style={input} placeholder="Password" secureTextEntry value={password} onChangeText={setPassword} />
      <Button label={mode === "in" ? "Sign in" : "Create account"} onPress={submit} disabled={busy || !email || password.length < 6} />
      <View style={{ alignItems: "center" }}>
        <Text onPress={() => setMode(mode === "in" ? "up" : "in")} style={{ color: c.fairway, padding: 8 }}>
          {mode === "in" ? "New here? Create an account" : "Have an account? Sign in"}
        </Text>
      </View>
    </KeyboardAvoidingView>
  );
}
