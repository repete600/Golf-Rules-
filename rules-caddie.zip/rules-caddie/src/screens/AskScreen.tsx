import React, { useRef, useState } from "react";
import { ActivityIndicator, Alert, Image, ScrollView, Text, TextInput, View, Pressable } from "react-native";
import { CameraView, useCameraPermissions } from "expo-camera";
import * as ImageManipulator from "expo-image-manipulator";
import { useFocusEffect } from "@react-navigation/native";
import { askRules, RuleAnswer } from "../lib/api";
import { supabase } from "../lib/supabase";
import { AnswerCard, Button } from "../components";
import { c } from "../theme";

type Photo = { uri: string; base64: string };

export default function AskScreen() {
  const [question, setQuestion] = useState("");
  const [photo, setPhoto] = useState<Photo | null>(null);
  const [camOpen, setCamOpen] = useState(false);
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState<RuleAnswer | null>(null);
  const [rounds, setRounds] = useState<any[]>([]);
  const cam = useRef<CameraView>(null);
  const [perm, requestPerm] = useCameraPermissions();

  useFocusEffect(React.useCallback(() => {
    supabase.from("rounds").select("id,name").order("created_at", { ascending: false }).then(({ data }) => setRounds(data ?? []));
  }, []));

  async function openCamera() {
    if (!perm?.granted && !(await requestPerm()).granted) return Alert.alert("Camera needed", "Allow camera access in Settings to photograph your lie.");
    setCamOpen(true);
  }

  async function snap() {
    const raw = await cam.current?.takePictureAsync({ quality: 0.6 });
    if (!raw) return;
    const small = await ImageManipulator.manipulateAsync(raw.uri, [{ resize: { width: 1024 } }],
      { compress: 0.6, format: ImageManipulator.SaveFormat.JPEG, base64: true });
    setPhoto({ uri: small.uri, base64: small.base64! });
    setCamOpen(false);
  }

  async function ask() {
    setBusy(true); setResult(null);
    try { setResult(await askRules(question.trim(), photo?.base64)); }
    catch (e: any) { Alert.alert("Couldn't get an answer", e.message); }
    setBusy(false);
  }

  async function share(roundId: string) {
    try {
      const uid = (await supabase.auth.getUser()).data.user?.id;
      const { data: me } = await supabase.from("round_members").select("display_name").eq("round_id", roundId).eq("user_id", uid).single();
      let image_path: string | null = null;
      if (photo) {
        image_path = `${roundId}/${Date.now()}.jpg`;
        const bytes = Uint8Array.from(atob(photo.base64), (ch) => ch.charCodeAt(0));
        const up = await supabase.storage.from("situation-photos").upload(image_path, bytes, { contentType: "image/jpeg" });
        if (up.error) throw up.error;
      }
      const { error } = await supabase.from("situations").insert({
        round_id: roundId, author_name: me?.display_name ?? "Player", question, image_path, ai_result: result,
      });
      if (error) throw error;
      Alert.alert("Shared", "Your group can now agree or disagree.");
    } catch (e: any) { Alert.alert("Couldn't share", e.message); }
  }

  if (camOpen) {
    return (
      <View style={{ flex: 1, backgroundColor: "#000" }}>
        <CameraView ref={cam} style={{ flex: 1 }} facing="back" />
        <View style={{ padding: 20, gap: 10, backgroundColor: "#000" }}>
          <Text style={{ color: c.sand, textAlign: "center" }}>Include the ball and what's around it: sand, stakes, cart path, trees.</Text>
          <Button label="Take photo" onPress={snap} />
          <Button label="Cancel" kind="ghost" onPress={() => setCamOpen(false)} />
        </View>
      </View>
    );
  }

  return (
    <ScrollView contentContainerStyle={{ padding: 16, gap: 14 }} keyboardShouldPersistTaps="handled">
      <TextInput
        style={{ minHeight: 96, borderWidth: 1, borderColor: c.line, backgroundColor: c.white, borderRadius: 10, padding: 14, fontSize: 16, textAlignVertical: "top", color: c.ink }}
        multiline placeholder="e.g. My ball is in a bunker against the rake. Can I move it?" value={question} onChangeText={setQuestion} />
      {photo && (
        <View>
          <Image source={{ uri: photo.uri }} style={{ height: 200, borderRadius: 10 }} />
          <Pressable onPress={() => setPhoto(null)} style={{ position: "absolute", right: 8, top: 8, backgroundColor: "#000A", borderRadius: 8, padding: 6 }}>
            <Text style={{ color: "#fff" }}>Remove</Text>
          </Pressable>
        </View>
      )}
      <View style={{ flexDirection: "row", gap: 10 }}>
        <View style={{ flex: 1 }}><Button label={photo ? "Retake photo" : "Photograph lie"} kind="ghost" onPress={openCamera} /></View>
        <View style={{ flex: 1 }}><Button label="Ask" onPress={ask} disabled={busy || question.trim().length < 5} /></View>
      </View>
      {busy && <ActivityIndicator color={c.fairway} />}
      {result && (
        <>
          <AnswerCard r={result} />
          {rounds.length > 0 && (
            <View style={{ gap: 8 }}>
              <Text style={{ color: c.rough }}>Share with a round for a group check:</Text>
              {rounds.map((r) => <Button key={r.id} label={r.name} kind="ghost" onPress={() => share(r.id)} />)}
            </View>
          )}
        </>
      )}
      <Text style={{ color: c.rough, fontSize: 12, textAlign: "center", marginTop: 8 }}>
        Guidance only, not a binding ruling. In competition, the Committee or a referee decides.
      </Text>
    </ScrollView>
  );
}
