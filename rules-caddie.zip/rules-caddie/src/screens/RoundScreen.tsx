import React, { useCallback, useEffect, useState } from "react";
import { FlatList, Image, Text, View } from "react-native";
import { supabase } from "../lib/supabase";
import { AnswerCard, Button, st } from "../components";
import { c } from "../theme";

export default function RoundScreen({ route }: any) {
  const roundId: string = route.params.id;
  const [items, setItems] = useState<any[]>([]);
  const [me, setMe] = useState<string | null>(null);

  const load = useCallback(async () => {
    const { data: sits } = await supabase.from("situations").select("*").eq("round_id", roundId).order("created_at", { ascending: false });
    const ids = (sits ?? []).map((x) => x.id);
    const { data: votes } = ids.length ? await supabase.from("votes").select("*").in("situation_id", ids) : { data: [] as any[] };
    const withExtras = await Promise.all((sits ?? []).map(async (x) => {
      let url: string | null = null;
      if (x.image_path) url = (await supabase.storage.from("situation-photos").createSignedUrl(x.image_path, 3600)).data?.signedUrl ?? null;
      return { ...x, url, votes: (votes ?? []).filter((v: any) => v.situation_id === x.id) };
    }));
    setItems(withExtras);
  }, [roundId]);

  useEffect(() => {
    supabase.auth.getUser().then(({ data }) => setMe(data.user?.id ?? null));
    load();
    const ch = supabase.channel(`round-${roundId}`)
      .on("postgres_changes", { event: "*", schema: "public", table: "situations", filter: `round_id=eq.${roundId}` }, load)
      .on("postgres_changes", { event: "*", schema: "public", table: "votes" }, load)
      .subscribe();
    return () => { supabase.removeChannel(ch); };
  }, [roundId, load]);

  async function vote(situation_id: string, v: "agree" | "disagree") {
    await supabase.from("votes").upsert({ situation_id, user_id: me, vote: v });
    load();
  }

  return (
    <FlatList
      data={items} keyExtractor={(x) => x.id} contentContainerStyle={{ padding: 16, gap: 14 }}
      ListEmptyComponent={<Text style={{ color: c.rough }}>Nothing shared yet. Ask a rule on the first tab, then share it here.</Text>}
      renderItem={({ item }) => {
        const agree = item.votes.filter((v: any) => v.vote === "agree").length;
        const disagree = item.votes.filter((v: any) => v.vote === "disagree").length;
        const mine = item.votes.find((v: any) => v.user_id === me)?.vote;
        return (
          <View style={{ gap: 8 }}>
            <Text style={{ color: c.rough }}>{item.author_name} asked:</Text>
            <Text style={{ color: c.ink, fontSize: 16 }}>{item.question}</Text>
            {item.url && <Image source={{ uri: item.url }} style={{ height: 190, borderRadius: 10 }} />}
            {item.ai_result && <AnswerCard r={item.ai_result} />}
            <View style={{ flexDirection: "row", gap: 10 }}>
              <View style={{ flex: 1 }}><Button label={`Agree (${agree})`} kind={mine === "agree" ? "primary" : "ghost"} onPress={() => vote(item.id, "agree")} /></View>
              <View style={{ flex: 1 }}><Button label={`Disagree (${disagree})`} kind={mine === "disagree" ? "primary" : "ghost"} onPress={() => vote(item.id, "disagree")} /></View>
            </View>
          </View>
        );
      }}
    />
  );
}
