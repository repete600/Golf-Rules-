import React, { useCallback, useState } from "react";
import { Alert, FlatList, Text, TextInput, View, Pressable } from "react-native";
import { useFocusEffect, useNavigation } from "@react-navigation/native";
import { supabase } from "../lib/supabase";
import { Button, st } from "../components";
import { c } from "../theme";

export default function RoundsScreen() {
  const nav = useNavigation<any>();
  const [rounds, setRounds] = useState<any[]>([]);
  const [name, setName] = useState("");
  const [code, setCode] = useState("");
  const [myName, setMyName] = useState("");

  const load = useCallback(() => {
    supabase.from("rounds").select("id,name,join_code").order("created_at", { ascending: false }).then(({ data }) => setRounds(data ?? []));
  }, []);
  useFocusEffect(load);

  async function create() {
    const { data, error } = await supabase.rpc("create_round", { round_name: name.trim(), my_name: myName.trim() });
    if (error) return Alert.alert("Couldn't create round", error.message);
    setName(""); load(); nav.navigate("Round", { id: data.id, name: data.name });
  }
  async function join() {
    const { data, error } = await supabase.rpc("join_round", { code, my_name: myName.trim() });
    if (error) return Alert.alert("Couldn't join", error.message);
    setCode(""); load(); nav.navigate("Round", { id: data.id, name: data.name });
  }

  const input = { borderWidth: 1, borderColor: c.line, backgroundColor: c.white, borderRadius: 10, padding: 12, fontSize: 16, color: c.ink } as const;
  return (
    <FlatList
      data={rounds} keyExtractor={(r) => r.id} contentContainerStyle={{ padding: 16, gap: 10 }}
      ListHeaderComponent={
        <View style={{ gap: 10, marginBottom: 10 }}>
          <TextInput style={input} placeholder="Your name (shown to your group)" value={myName} onChangeText={setMyName} />
          <TextInput style={input} placeholder="New round name, e.g. Saturday foursome" value={name} onChangeText={setName} />
          <Button label="Start round" onPress={create} disabled={!name.trim() || !myName.trim()} />
          <TextInput style={input} placeholder="Join code" autoCapitalize="characters" value={code} onChangeText={setCode} />
          <Button label="Join round" kind="ghost" onPress={join} disabled={code.trim().length < 4 || !myName.trim()} />
        </View>
      }
      ListEmptyComponent={<Text style={{ color: c.rough }}>No rounds yet. Start one and share the code with your group.</Text>}
      renderItem={({ item }) => (
        <Pressable onPress={() => nav.navigate("Round", { id: item.id, name: item.name })} style={st.card}>
          <Text style={{ fontSize: 18, color: c.ink, fontWeight: "600" }}>{item.name}</Text>
          <Text style={{ color: c.rough }}>Code {item.join_code}</Text>
        </Pressable>
      )}
    />
  );
}
