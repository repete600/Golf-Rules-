import { supabase } from "./supabase";

export type RuleAnswer = {
  situation_summary: string;
  answer: string;
  rules_cited: { rule_number: string; title: string }[];
  steps: string[];
  confidence: "high" | "medium" | "low";
  needs_official: boolean;
  follow_up_question?: string | null;
};

export async function askRules(question: string, imageBase64?: string): Promise<RuleAnswer> {
  const { data, error } = await supabase.functions.invoke("rules-assistant", {
    body: { question, imageBase64 },
  });
  if (error) throw new Error(error.message ?? "Could not reach the rules assistant");
  if (data?.error) throw new Error(data.error);
  return data as RuleAnswer;
}
