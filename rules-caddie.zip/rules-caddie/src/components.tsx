import React from "react";
import { Text, View, Pressable, StyleSheet } from "react-native";
import { c, s, serif } from "./theme";
import type { RuleAnswer } from "./lib/api";

export const Button = ({ label, onPress, kind = "primary", disabled }: any) => (
  <Pressable onPress={onPress} disabled={disabled} accessibilityRole="button"
    style={({ pressed }) => [st.btn, kind === "ghost" && st.ghost, disabled && { opacity: 0.4 }, pressed && { opacity: 0.8 }]}>
    <Text style={[st.btnText, kind === "ghost" && { color: c.fairway }]}>{label}</Text>
  </Pressable>
);

const confColor = { high: c.fairway, medium: "#9A7B1F", low: c.flag } as const;

export function AnswerCard({ r }: { r: RuleAnswer }) {
  return (
    <View style={st.card}>
      <Text style={st.muted}>{r.situation_summary}</Text>
      <Text style={st.answer}>{r.answer}</Text>
      {r.steps?.map((t, i) => <Text key={i} style={st.step}>{i + 1}. {t}</Text>)}
      <View style={st.row}>
        {r.rules_cited?.map((x) => (
          <View key={x.rule_number} style={st.chip}><Text style={st.chipText}>Rule {x.rule_number}</Text></View>
        ))}
      </View>
      <Text style={[st.conf, { color: confColor[r.confidence] }]}>
        Confidence: {r.confidence}{r.needs_official ? " — check with a referee or the Committee" : ""}
      </Text>
      {r.follow_up_question ? <Text style={st.follow}>To be sure: {r.follow_up_question}</Text> : null}
    </View>
  );
}

export const st = StyleSheet.create({
  btn: { backgroundColor: c.fairway, paddingVertical: 14, paddingHorizontal: 18, borderRadius: s.radius, alignItems: "center" },
  ghost: { backgroundColor: "transparent", borderWidth: 1.5, borderColor: c.fairway },
  btnText: { color: c.white, fontWeight: "600", fontSize: 16 },
  card: { backgroundColor: c.white, borderRadius: s.radius, padding: s.pad, borderWidth: 1, borderColor: c.line, gap: 8 },
  muted: { color: c.rough, fontSize: 13, fontStyle: "italic" },
  answer: { color: c.ink, fontSize: 17, lineHeight: 24, fontFamily: serif },
  step: { color: c.ink, fontSize: 15, lineHeight: 21 },
  row: { flexDirection: "row", flexWrap: "wrap", gap: 6 },
  chip: { backgroundColor: c.sand, borderRadius: 6, paddingHorizontal: 8, paddingVertical: 4 },
  chipText: { color: c.ink, fontSize: 13, fontWeight: "600" },
  conf: { fontSize: 13, fontWeight: "600" },
  follow: { color: c.ink, fontSize: 14, backgroundColor: c.paper, padding: 10, borderRadius: 8 },
});
