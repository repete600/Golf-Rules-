import { Platform } from "react-native";
export const c = {
  fairway: "#1F3D2B", paper: "#F7F5EE", sand: "#E6D8B5", flag: "#C8372D",
  ink: "#17211B", rough: "#5B6B5E", line: "#D9D4C3", white: "#FFFFFF",
};
export const serif = Platform.select({ ios: "Georgia", android: "serif", default: "serif" });
export const s = { pad: 16, radius: 10 };
